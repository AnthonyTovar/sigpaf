<?php
require_once 'model/UsuarioModel.php';
require_once 'ValidationHelper.php';
require_once 'Logger.php';

class UsuarioController
{
    private $model;

    public function __construct()
    {
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }
        $this->model = new UsuarioModel();
    }

    private function renderizar($nombreVista, $datos = [])
    {
        extract($datos);
        ob_start();
        require $nombreVista . '.php';
        $content = ob_get_clean();

        require 'view/Layout.php';
    }

    public function listar()
    {
        if (!isset($_SESSION['usuario_id'])) {
            header("Location: index.php?action=login");
            exit();
        }

        $usuarios = $this->model->listarUsuarios();
        $tiposUsuario = $this->model->listarTiposUsuario();
        $empleados = $this->model->listarEmpleadosSinUsuario();
        $this->renderizar('view/UsuarioView', [
            'usuarios' => $usuarios,
            'tiposUsuario' => $tiposUsuario,
            'empleados' => $empleados
        ]);
    }

    // ============================================
    // NUEVO: BUSCAR EMPLEADO POR CÉDULA (AJAX)
    // ============================================
    public function buscarEmpleadoPorCedula()
    {
        header('Content-Type: application/json');

        $cedula = $_GET['cedula'] ?? '';

        if (empty($cedula)) {
            echo json_encode(["status" => "error", "message" => "Cédula no proporcionada."]);
            exit;
        }

        $empleado = $this->model->buscarEmpleadoPorCedula($cedula);

        if (!$empleado) {
            echo json_encode(["status" => "no_existe", "message" => "No se encontró un empleado con esa cédula."]);
            exit;
        }

        $idUsuario = $this->model->empleadoTieneUsuario($empleado['idEmpleado']);

        if ($idUsuario) {
            echo json_encode([
                "status" => "ya_tiene_usuario",
                "message" => "Este empleado ya tiene un usuario asignado.",
                "idUsuario" => $idUsuario,
                "nombres" => $empleado['nombres'],
                "apellidos" => $empleado['apellidos']
            ]);
            exit;
        }

        echo json_encode([
            "status" => "success",
            "message" => "Empleado encontrado y disponible.",
            "idEmpleado" => $empleado['idEmpleado'],
            "cedulaEmpleado" => $empleado['cedulaEmpleado'],
            "nombres" => $empleado['nombres'],
            "apellidos" => $empleado['apellidos']
        ]);
        exit;
    }

    public function guardar()
    {
        header('Content-Type: application/json');

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $nombreUsuario = $_POST['nombreUsuario'] ?? '';
            $contrasena = $_POST['contrasena'] ?? '';
            $confirmarContrasena = $_POST['confirmarContrasena'] ?? '';
            $idTipoUsuario = $_POST['idTipoUsuario'] ?? '';
            $idEmpleado = $_POST['idEmpleado'] ?? '';

            // ===== VALIDACIÓN UNIFICADA (ValidationHelper) =====
            ValidationHelper::exigirRequerido($nombreUsuario, 'El nombre de usuario es obligatorio.');
            ValidationHelper::exigirMaxLongitud($nombreUsuario, 'El nombre de usuario es muy largo', 50);
            ValidationHelper::exigirRequerido($contrasena, 'La contraseña es obligatoria.');
            if (!(strlen($contrasena) >= 6)) {
                ValidationHelper::error('La contraseña debe tener al menos 6 caracteres.');
            }
            if (!($contrasena === $confirmarContrasena)) {
                ValidationHelper::error('Las contraseñas no coinciden.');
            }
            ValidationHelper::exigirRequerido($idTipoUsuario, 'Debe seleccionar el tipo de usuario.');
            ValidationHelper::exigirRequerido($idEmpleado, 'Debe seleccionar el empleado.');
            if (empty($nombreUsuario) || empty($contrasena) || empty($idTipoUsuario) || empty($idEmpleado)) {
                echo json_encode([
                    "status" => "error",
                    "message" => "Todos los campos son obligatorios."
                ]);
                exit();
            }

            if ($contrasena !== $confirmarContrasena) {
                echo json_encode([
                    "status" => "error",
                    "message" => "Las contraseñas no coinciden."
                ]);
                exit();
            }

            if ($this->model->verificarNombreUsuario($nombreUsuario)) {
                echo json_encode([
                    "status" => "error",
                    "message" => "El nombre de usuario ya existe."
                ]);
                exit();
            }


            // ===== VALIDACIÓN DE DUPLICADO (mensaje estándar del sistema) =====
            if (ValidationHelper::esDuplicado($this->model->listarUsuarios(), 'nombreUsuario', $nombreUsuario)) {
                ValidationHelper::errorDuplicado('un usuario', 'el nombre', $nombreUsuario);
            }

            $nuevoId = $this->model->registrarUsuarioMaestro($nombreUsuario, $contrasena, $idTipoUsuario, $idEmpleado);

            if ($nuevoId) {
                // Bitacora: registro creado
                Logger::crear('Usuario', $nuevoId, $nombreUsuario);
                echo json_encode([
                    "status" => "success",
                    "message" => "¡Usuario registrado con éxito!",
                    "id" => $nuevoId,
                    "nombreUsuario" => $nombreUsuario,
                    "idTipoUsuario" => $idTipoUsuario,
                    "idEmpleado" => $idEmpleado
                ]);
            } else {
                echo json_encode([
                    "status" => "error",
                    "message" => "Hubo un error en la base de datos."
                ]);
            }
            exit();
        }
    }

    public function eliminar()
    {
        header('Content-Type: application/json');

        $id = $_POST['idUsuario'] ?? null;

        if (!$id) {
            echo json_encode(["status" => "error", "message" => "No se recibió el ID del usuario"]);
            exit;
        }

        // Consulta el nombre antes de eliminar para la bitacora
        $reg = $this->model->obtenerUsuarioPorId($id);

        $resultado = $this->model->eliminarUsuario($id);

        if ($resultado === true) {
            // Bitacora: registro eliminado
            Logger::eliminar('Usuario', $id, $reg ? $reg['nombreUsuario'] : 'desconocido');
            echo json_encode(["status" => "success", "message" => "Usuario eliminado correctamente"]);
        } else if ($resultado === "link") {
            echo json_encode(["status" => "error", "message" => "No se puede eliminar: Este usuario tiene registros vinculados."]);
        } else {
            echo json_encode(["status" => "error", "message" => "Error interno al intentar eliminar el usuario."]);
        }
        exit;
    }

    public function consultar()
    {
        $id = $_GET['id'] ?? '';
        $usuario = $this->model->obtenerUsuarioPorId($id);
        echo json_encode($usuario);
        exit;
    }

    public function editar()
    {
        header('Content-Type: application/json');

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $id = $_POST['idUsuarioEdit'] ?? '';
            $nombreUsuario = $_POST['nombreUsuarioEdit'] ?? '';
            $contrasena = $_POST['contrasenaEdit'] ?? '';
            $idTipoUsuario = $_POST['idTipoUsuarioEdit'] ?? '';
            $idEmpleado = $_POST['idEmpleadoEdit'] ?? '';

            // ===== VALIDACIÓN UNIFICADA (ValidationHelper) =====
            ValidationHelper::exigirRequerido($id, 'No se recibió el usuario a editar.');
            ValidationHelper::exigirRequerido($nombreUsuario, 'El nombre de usuario es obligatorio.');
            ValidationHelper::exigirMaxLongitud($nombreUsuario, 'El nombre de usuario es muy largo', 50);
            if (!($contrasena === '' || strlen($contrasena) >= 6)) {
                ValidationHelper::error('La contraseña debe tener al menos 6 caracteres.');
            }
            ValidationHelper::exigirRequerido($idTipoUsuario, 'Debe seleccionar el tipo de usuario.');
            ValidationHelper::exigirRequerido($idEmpleado, 'Debe seleccionar el empleado.');
            if (empty($id) || empty($nombreUsuario) || empty($idTipoUsuario) || empty($idEmpleado)) {
                echo json_encode([
                    "status" => "error",
                    "message" => "Los campos obligatorios son: Nombre de Usuario, Tipo de Usuario y Empleado."
                ]);
                exit();
            }

            // ===== VALIDACIÓN DE DUPLICADO (mensaje estándar del sistema) =====
            if (ValidationHelper::esDuplicado($this->model->listarUsuarios(), 'nombreUsuario', $nombreUsuario, 'idUsuario', $id)) {
                ValidationHelper::errorDuplicado('un usuario', 'el nombre', $nombreUsuario);
            }

            $resultado = $this->model->actualizarUsuario($id, $nombreUsuario, $contrasena, $idTipoUsuario, $idEmpleado);

            if ($resultado) {
                // Bitacora: registro actualizado
                Logger::actualizar('Usuario', $id, $nombreUsuario);
                echo json_encode([
                    "status" => "success",
                    "message" => "¡Usuario actualizado con éxito!"
                ]);
            } else {
                echo json_encode([
                    "status" => "error",
                    "message" => "No se realizaron cambios o hubo un error."
                ]);
            }
            exit();
        }
    }

    // ============================================
    // GESTIÓN DE USUARIO PROPIO - TODOS LOS ROLES
    // ============================================

    public function gestionUsuario()
    {
        if (!isset($_SESSION['usuario_id'])) {
            header("Location: index.php?action=login");
            exit();
        }

        $usuario = $this->model->obtenerUsuarioPorId($_SESSION['usuario_id']);
        $this->renderizar('view/GestionUsuarioView', [
            'usuario' => $usuario
        ]);
    }

    public function actualizarPerfil()
    {
        header('Content-Type: application/json');

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $id = $_SESSION['usuario_id'];
            $nombreUsuario = $_POST['nombreUsuarioPerfil'] ?? '';
            $contrasena = $_POST['contrasenaPerfil'] ?? '';

            if (empty($nombreUsuario)) {
                echo json_encode([
                    "status" => "error",
                    "message" => "El nombre de usuario es obligatorio."
                ]);
                exit();
            }

            if ($this->model->verificarNombreUsuario($nombreUsuario, $id)) {
                echo json_encode([
                    "status" => "error",
                    "message" => "Ya existe otro usuario con el nombre '{$nombreUsuario}'. Verifique e inténtelo con otro."
                ]);
                exit();
            }

            $resultado = $this->model->actualizarPerfil($id, $nombreUsuario, $contrasena);

            if ($resultado) {
                $_SESSION['username'] = $nombreUsuario;
                echo json_encode([
                    "status" => "success",
                    "message" => "¡Perfil actualizado con éxito!"
                ]);
            } else {
                echo json_encode([
                    "status" => "error",
                    "message" => "No se realizaron cambios o hubo un error."
                ]);
            }
            exit();
        }
    }

    // Exporta el listado a PDF con Dompdf (se muestra en el navegador)
    public function exportarPdf()
    {
        if (!isset($_SESSION['usuario_id'])) {
            header("Location: index.php?action=login");
            exit();
        }

        require_once 'lib/dompdf/autoload.inc.php';
        require_once 'Logger.php';

        $registros = $this->model->listarUsuarios();

        // Filtro de busqueda: el PDF exporta solo lo filtrado en pantalla
        $filtro = trim((string) ($_GET['q'] ?? ''));
        if ($filtro !== '') {
            $registros = array_values(array_filter($registros, function ($r) use ($filtro) {
                foreach ($r as $v) {
                    if (mb_stripos((string) $v, $filtro) !== false) {
                        return true;
                    }
                }
                return false;
            }));
        }

        ob_start();
        require 'view/public/reportes/UsuariosReporteView.php';
        $html = ob_get_clean();

        $options = new \Dompdf\Options();
        $options->set('isRemoteEnabled', true);
        $options->set('defaultFont', 'Helvetica');

        $dompdf = new \Dompdf\Dompdf($options);
        $dompdf->setPaper('letter', 'landscape');
        $dompdf->loadHtml($html, 'UTF-8');
        $dompdf->render();

        Logger::registrar('GENERAR', 'Configuracion', null, 'Generó PDF de Usuarios del Sistema');

        // Attachment => false: se MUESTRA en el navegador
        $dompdf->stream("reporte_usuarios_sigpaf.pdf", ["Attachment" => false]);
        exit();
    }
}