<?php
// Construye la URL del PDF con los mismos filtros aplicados en pantalla
$parametrosPdf = array_filter($filtros);
$urlPdf = 'index.php?action=exportarPdfActividades';
if (!empty($parametrosPdf)) {
    $urlPdf .= '&' . http_build_query($parametrosPdf);
}
?>
<div class="container-fluid py-4">
    <div style="height: 0; position: relative;">
        <div id="registro-alerta" class="alert shadow-sm"
            style="display:none; position: absolute; top: -50px; left: 0; right: 0; z-index: 1; margin: 0 1px;"
            role="alert">
            <i id="alerta-icono" class="bi"></i>
            <span id="alerta-texto"></span>
        </div>
    </div>
    <div class="row" style="margin-top: 10px">
        <div class="col-12">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><i class="bi bi-calendar-event me-2"></i> Gestión de Actividades</h5>
                    <div class="d-flex gap-2">
                        <a href="index.php?action=nuevaActividad" class="btn btn-light btn-sm fw-bold">
                            <i class="bi bi-plus-circle-fill me-1"></i> Nueva Actividad
                        </a>
                        <a href="<?php echo $urlPdf; ?>" class="btn btn-danger btn-sm fw-bold"
                            target="_blank" title="Ver las actividades en PDF con los filtros aplicados">
                            <i class="bi bi-file-earmark-pdf me-1"></i> Exportar
                        </a>
                    </div>
                </div>

                <div class="card-body">
                    <!-- FILTROS -->
                    <form method="GET" action="index.php" class="border rounded bg-light p-3 mb-3">
                        <input type="hidden" name="action" value="actividades">
                        <div class="row g-2 align-items-end">
                            <div class="col-6 col-md-2">
                                <label for="filtro-desde" class="form-label small fw-bold text-muted mb-1">
                                    <i class="bi bi-calendar-event me-1"></i>Desde
                                </label>
                                <input type="date" id="filtro-desde" name="desde" class="form-control form-control-sm"
                                       value="<?php echo $filtros['desde']; ?>">
                            </div>
                            <div class="col-6 col-md-2">
                                <label for="filtro-hasta" class="form-label small fw-bold text-muted mb-1">
                                    <i class="bi bi-calendar-check me-1"></i>Hasta
                                </label>
                                <input type="date" id="filtro-hasta" name="hasta" class="form-control form-control-sm"
                                       value="<?php echo $filtros['hasta']; ?>">
                            </div>
                            <div class="col-6 col-md-2">
                                <label for="filtro-estatus" class="form-label small fw-bold text-muted mb-1">
                                    <i class="bi bi-flag me-1"></i>Estatus
                                </label>
                                <select id="filtro-estatus" name="idEstatus" class="form-select form-select-sm">
                                    <option value="">Todos</option>
                                    <?php foreach ($estatus as $e): ?>
                                        <option value="<?php echo $e['idEstatus']; ?>"
                                            <?php echo ($filtros['idEstatus'] === $e['idEstatus']) ? 'selected' : ''; ?>>
                                            <?php echo $e['nomEstatus']; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-6 col-md-2">
                                <label for="filtro-tipo" class="form-label small fw-bold text-muted mb-1">
                                    <i class="bi bi-tag me-1"></i>Tipo de Actividad
                                </label>
                                <select id="filtro-tipo" name="idTipoActividad" class="form-select form-select-sm">
                                    <option value="">Todos</option>
                                    <?php foreach ($tiposActividad as $t): ?>
                                        <option value="<?php echo $t['idTipoActividad']; ?>"
                                            <?php echo ($filtros['idTipoActividad'] === $t['idTipoActividad']) ? 'selected' : ''; ?>>
                                            <?php echo $t['nomTipoActividad']; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-12 col-md-2">
                                <label for="filtro-responsable" class="form-label small fw-bold text-muted mb-1">
                                    <i class="bi bi-person me-1"></i>Responsable
                                </label>
                                <select id="filtro-responsable" name="responsable" class="form-select form-select-sm">
                                    <option value="">Todos</option>
                                    <optgroup label="Empleados">
                                        <?php foreach ($empleados as $em): ?>
                                            <option value="<?php echo $em['idEmpleado']; ?>"
                                                <?php echo ($filtros['responsable'] === $em['idEmpleado']) ? 'selected' : ''; ?>>
                                                <?php echo $em['nombreCompleto']; ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </optgroup>
                                    <optgroup label="Docentes">
                                        <?php foreach ($docentes as $dc): ?>
                                            <option value="<?php echo $dc['idDocente']; ?>"
                                                <?php echo ($filtros['responsable'] === $dc['idDocente']) ? 'selected' : ''; ?>>
                                                <?php echo $dc['nombreCompleto']; ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </optgroup>
                                </select>
                            </div>
                            <div class="col-12 col-md-2 d-flex gap-2">
                                <button type="submit" class="btn btn-primary btn-sm fw-bold flex-fill">
                                    <i class="bi bi-funnel-fill me-1"></i> Filtrar
                                </button>
                                <a href="index.php?action=actividades" class="btn btn-outline-secondary btn-sm fw-bold" title="Limpiar filtros">
                                    <i class="bi bi-eraser-fill"></i>
                                </a>
                            </div>
                        </div>
                    </form>
                    <!-- FIN FILTROS -->

                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>Código</th>
                                    <th>Actividad</th>
                                    <th>Fechas</th>
                                    <th>Sesiones</th>
                                    <th>Responsables</th>
                                    <th>Lugar</th>
                                    <th>Estatus</th>
                                    <th class="text-center">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($actividades)): ?>
                                    <?php foreach ($actividades as $a): ?>
                                        <tr>
                                            <td><span class="badge bg-secondary px-2 py-1"><?php echo $a['idActividad']; ?></span></td>
                                            <td>
                                                <div class="fw-bold text-dark"><?php echo $a['nombreActividad']; ?></div>
                                                <div class="text-muted small"><?php echo $a['nomTipoActividad']; ?> | <?php echo $a['nombreVertice']; ?></div>
                                            </td>
                                            <td>
                                                <div class="small">
                                                    <i class="bi bi-calendar-event text-primary me-1"></i>
                                                    <?php echo date('d/m/Y', strtotime($a['fechainicioActividad'])); ?>
                                                </div>
                                                <div class="small text-muted">
                                                    <i class="bi bi-calendar-check text-success me-1"></i>
                                                    <?php echo date('d/m/Y', strtotime($a['fechafinActividad'])); ?>
                                                </div>
                                            </td>
                                            <td class="text-center">
                                                <span class="badge bg-info"><?php echo $a['cantSesionesPlanificada']; ?> sesiones</span>
                                            </td>
                                            <td>
                                                <div class="small"><i class="bi bi-person me-1 text-primary"></i><?php echo htmlspecialchars(implode(', ', array_column($a['empleadosLista'], 'nombreCompleto'))); ?></div>
                                                <div class="small text-muted"><i class="bi bi-person-badge me-1 text-warning"></i><?php echo htmlspecialchars(implode(', ', array_column($a['docentesLista'], 'nombreCompleto'))); ?></div>
                                            </td>
                                            <td>
                                                <span class="small text-muted"><?php echo htmlspecialchars(implode(', ', array_column($a['lugaresLista'], 'nomLugarActividad'))); ?></span>
                                            </td>
                                            <td>
                                                <?php
                                                    // Mismo criterio de colores que el resto del sistema:
                                                    // verde = finalizada, rojo = cancelada/en espera,
                                                    // amarillo = los demás estatus
                                                    $est = strtolower($a['nomEstatus']);
                                                    $claseEstatus = (strpos($est, 'final') !== false) ? 'bg-success'
                                                        : ((strpos($est, 'cancel') !== false || strpos($est, 'espera') !== false) ? 'bg-danger' : 'bg-warning text-dark');
                                                ?>
                                                <span class="badge <?php echo $claseEstatus; ?>">
                                                    <?php echo $a['nomEstatus']; ?>
                                                </span>
                                            </td>
                                            <td class="text-center">
                                                <div class="btn-group" role="group">
                                                    <button class="btn btn-outline-info btn-sm border-0 btn-ver" data-id="<?php echo $a['idActividad']; ?>" title="Ver detalle">
                                                        <i class="bi bi-eye"></i>
                                                    </button>
                                                    <button class="btn btn-outline-warning btn-sm border-0 btn-editar" data-id="<?php echo $a['idActividad']; ?>" title="Editar">
                                                        <i class="bi bi-pencil-square"></i>
                                                    </button>
                                                    <button class="btn btn-outline-danger btn-sm border-0 btn-eliminar" data-id="<?php echo $a['idActividad']; ?>" title="Eliminar">
                                                        <i class="bi bi-trash3-fill"></i>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr><td colspan="8" class="text-center py-4 text-muted"><i class="bi bi-info-circle me-1"></i> No hay actividades registradas actualmente.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- MODAL VER DETALLE -->
<div class="modal fade" id="modalVerActividad" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content border-0 shadow">
            <div class="modal-header bg-info text-white">
                <h5 class="modal-title"><i class="bi bi-eye me-2"></i>Detalle de Actividad</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4" id="detalle-actividad-content">
                <!-- Se carga dinámicamente -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
</div>

<script src="view/public/js/actividadListar.js?v=2026-10-26.1"></script>